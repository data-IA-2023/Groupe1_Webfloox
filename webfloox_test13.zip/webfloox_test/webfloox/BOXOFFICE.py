from boxoffice_api import BoxOffice 



box_office = BoxOffice()
box_office = BoxOffice(outputformat="DF")
print(box_office)