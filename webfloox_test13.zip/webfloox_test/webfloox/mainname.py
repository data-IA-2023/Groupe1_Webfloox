from typing import Optional
from fastapi import FastAPI, HTTPException
import requests
from pydantic import BaseModel

app = FastAPI()

# Replace "your_api_key_here" with your actual OMDB API key.
api_key = "bc442c47"

class Movie(BaseModel):
    title: str
    year: str
    rated: str
    released: str
    runtime: str
    genre: str
    director: str
    writer: str
    actors: str
    plot: str
    language: str
    country: str
    awards: str
    poster: str
    ratings: list
    metascore: str
    imdbRating: str
    imdbVotes: str
    imdbID: str
    type: str
    dvd: str
    boxOffice: str
    production: str
    website: str
    response: str

@app.get("/movies/", response_model=Movie)
def read_movie_by_name(movie_name: str):
    """
    Fetch movie details by name.
    """
    url = f"http://www.omdbapi.com/?t={movie_name}&apikey={api_key}"
    
    try:
        response = requests.get(url)
        response.raise_for_status() 
    except requests.RequestException as e:
        raise HTTPException(status_code=400, detail=f"Error fetching movie details: {e}")
    
    movie_data = response.json()
    if movie_data.get("Response", "False") == "False":
        raise HTTPException(status_code=404, detail="Movie not found")
    
    return movie_data

@app.get("/movies/{movie_name}/image")
def read_movie_image(movie_name: str):
    api_key = "bc442c47"  
    movies_images_url = f"http://img.omdbapi.com/?t={movie_name}&apikey={api_key}"
    return {"image_url": movies_images_url}
