from fastapi import FastAPI, Request, Form, Depends, HTTPException ,Query , Body
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
import os
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional, List
import crud, models, schemas
from crud import get_user
from database import SessionLocal, engine
import bcrypt
from typing import List
from datetime import datetime
from calendar import monthrange
import requests
import pandas as pd
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
import database
from fastapi.responses import HTMLResponse
from fastapi.encoders import jsonable_encoder
from cryptography.fernet import Fernet
from starlette.middleware.sessions import SessionMiddleware
from database import SessionLocal, engine   
from models import Like , User
from schemas import UserCreate
from fastapi import APIRouter
from search_movie import  get_movie_id_by_title ,get_similar_movies, get_movie_title_by_id , get_recommendations1
templates = Jinja2Templates(directory="templates")
from pydantic import BaseModel
from recom import search_movies,get_movie_details,get_recommendations
import random
from fastapi.responses import JSONResponse

app = FastAPI()
database.Base.metadata.create_all(bind=engine)
app.mount("/static", StaticFiles(directory="static"), name="static")

# Jinja2 Templates
templates = Jinja2Templates(directory="templates")
app.add_middleware(SessionMiddleware, secret_key="A2310")

app = FastAPI()
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

def fetch_movies(api_key: str, category: str):
    base_url = "https://api.themoviedb.org/3"
    
    image_base_url = "https://image.tmdb.org/t/p/w500"
    
    if category == "upcoming":
        url = f"{base_url}/movie/upcoming?api_key={api_key}&language=en-US&page=1"
    elif category == "now_playing":
        url = f"{base_url}/movie/now_playing?api_key={api_key}&language=en-US&page=1"
    else:
        return pd.DataFrame()  
    
    response = requests.get(url)
    if response.status_code != 200:
        return pd.DataFrame()  

    movies = response.json().get('results', [])
    movie_details_list = []
    for movie in movies:
        poster_url = f"{image_base_url}{movie['poster_path']}" if movie.get('poster_path') else None
        movie_details_list.append({
        'id': movie.get('id'),
            'title': movie.get('title'),
            'release_date': movie.get('release_date'),
            'poster_url': poster_url,
            'overview': movie.get('overview'),
            'genre':movie.get('genre')
        })
    
    return pd.DataFrame(movie_details_list)



app.add_middleware(
    SessionMiddleware,
    secret_key="A2310"  
)
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

movie_titles = ["avatar" , "Batman" , "The Matrix", "avengers"]

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request, title: Optional[str] = None, db: Session = Depends(get_db), q: str = "", num_recommendations: int = 3):
    user_id = request.session.get('user_id', None)
    user = None
    if user_id:
        user = get_user(db, user_id=user_id)
    
    # Movie fetching
    api_key = os.getenv('TMDB_API_KEY', 'b7cd3340a794e5a2f35e3abb820b497f')
    upcoming_df = fetch_movies(api_key, "upcoming")
    now_playing_df = fetch_movies(api_key, "now_playing")
    
    upcoming_movies = upcoming_df.to_dict(orient="records") if not upcoming_df.empty else []
    now_playing_movies = now_playing_df.to_dict(orient="records") if not now_playing_df.empty else []
   


    all_recommendations = pd.DataFrame()
    
    if len(movie_titles) == 0:
        raise HTTPException(status_code=400, detail="No movie titles provided.")
    
    
    if len(movie_titles) <= 2:
        num_rec = 5
    else:
        num_rec = num_recommendations

    for title in movie_titles:
        recommendations = get_recommendations(title, num_recommendations=num_rec)
        all_recommendations = pd.concat([all_recommendations, recommendations], ignore_index=True)

    # Remove potential duplicates
    all_recommendations.drop_duplicates(subset=['title'], inplace=True)

    if all_recommendations.empty:
        return {"message": "No recommendations available."}
    
    recommendations_list = all_recommendations.to_dict('records')


    # Combined template response
    return templates.TemplateResponse("index.html", {
        "request": request,
        "user": user,
        "movies": recommendations_list,
        "now_movies": now_playing_movies     
    })




@app.post("/signup")
async def signup(request: Request, db: Session = Depends(get_db)):
    form_data = await request.form()
    user_data = UserCreate(
        username=form_data.get("username"),
        email=form_data.get("email"),
        password=form_data.get("password")
    )
    if crud.get_user_by_email(db, email=user_data.email):
        raise HTTPException(status_code=400, detail="Email already registered")
    crud.create_user(db, user=user_data)
    return RedirectResponse(url="/login", status_code=303)

@app.get("/signup")
async def get_signup(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})
@app.get("/login")
async def get_signup(request: Request):
    # Return the signup page
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(request: Request, db: Session = Depends(get_db)):
    form_data = await request.form()
    username = form_data.get("username")
    password = form_data.get("password")
    user = crud.authenticate_user(db, username=username, password=password)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    request.session['user_id'] = str(user.id)
    return RedirectResponse(url="/", status_code=303)


@app.get("/logout")
async def logout(request: Request):
    request.session.pop('user_id', None)
    return RedirectResponse(url="/", status_code=303)

 
async def get_current_user(request: Request, db: Session = Depends(get_db)):
    user_id = request.session.get("user_id")
    if user_id is not None:
        return crud.get_user(db, user_id=user_id)
    return None

@app.get("/search_movie", response_class=HTMLResponse)
async def search_movie(request: Request, id: int = Query(None, alias="id") ):
    # Fetch movie details directly using the ID
    movie_details =  get_movie_details(id)
    if not movie_details:
        raise HTTPException(status_code=404, detail="Movie not found")

    # Fetch similar movies and recommendations based on movie ID
    similar_movies =  get_recommendations1(id)
    title1 = get_movie_title_by_id(id)
    title1= [title1]
    recommendations =  get_recommendations(title1,num_recommendations=10)
    recommendations_list = recommendations.to_dict('records')

    return templates.TemplateResponse("movie_details.html", {
        "request": request,
        "movie": movie_details,
        "movies": similar_movies,  
        "moviesr": recommendations_list   
    })


@app.post("/toggle-like")
async def toggle_like(request: Request, movie_title: str = Form(), db: Session = Depends(get_db)):
    
    current_user_id = 1

    liked_movie = db.query(Like).filter(Like.user_id == current_user_id, Like.movie_title == movie_title).first()

    if liked_movie:
        # If already liked, remove the like
        db.delete(liked_movie)
    else:
        # If not liked, add a new like
        new_like = Like(user_id=current_user_id, movie_title=movie_title)
        db.add(new_like)
        
    
    db.commit()

    return 



if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
