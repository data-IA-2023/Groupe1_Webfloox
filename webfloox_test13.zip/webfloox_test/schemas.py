from pydantic import BaseModel

class UserCreate(BaseModel):
    username: str
    email: str
    password: str


from typing import Optional

class MovieDetail(BaseModel):
    title: str
    release_date: str
    poster_url:  str
    overview:  str  