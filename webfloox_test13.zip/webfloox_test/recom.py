from fastapi import FastAPI, HTTPException
from typing import List
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from sklearn.preprocessing import MinMaxScaler
import tmdbsimple as tmdb
import requests

import requests

import random
app = FastAPI()

tmdb.API_KEY ='b7cd3340a794e5a2f35e3abb820b497f'
# movie_titles = ["Inception"]
def search_movies(query):
    search = tmdb.Search()
    response = search.movie(query=query)
    movies = []
    for result in response['results']:
        movie_dict = {
            'id': result['id'],
            'title': result['title'],
            'overview': result['overview']
        }
        movies.append(movie_dict)
    return pd.DataFrame(movies)



def get_movie_details(movie_id):
    api_key = 'b7cd3340a794e5a2f35e3abb820b497f'
    movie_url = f'https://api.themoviedb.org/3/movie/{movie_id}'
    credits_url = f'https://api.themoviedb.org/3/movie/{movie_id}/credits'
    params = {'api_key': api_key}
    
    movie_response = requests.get(movie_url, params=params)
    credits_response = requests.get(credits_url, params=params)
    
    if movie_response.status_code == 200 and credits_response.status_code == 200:
        movie_data = movie_response.json()
        credits_data = credits_response.json()
        
        # Director(s)
        directors = [crew['name'] for crew in credits_data.get('crew', []) if crew['job'] == 'Director']
        
        # Top 3 actors
        actors = [cast['name'] for cast in credits_data.get('cast', [])[:3]]
        
        return {
            'id': movie_data.get('id', 'ID Not Found'),  
            'title': movie_data.get('title', 'Title Not Found'),
            'poster_url': f"https://image.tmdb.org/t/p/w500{movie_data.get('poster_path', '')}" if movie_data.get('poster_path') else 'No Poster URL',
            'genres': [genre['name'] for genre in movie_data.get('genres', [])],
            'overview': movie_data.get('overview', 'No Overview Found'),
            'directors': directors,
            'actors': actors,
            'vote_average': movie_data.get('vote_average', 'Rating Not Available'),
            'vote_count': movie_data.get('vote_count', 'Votes Not Available')
        }
    else:
        return 'Failed to fetch data'
    




def get_recommendations(movie_title, num_recommendations=5):
    df = search_movies(movie_title)  
    if df.empty:
        print(f"No movies found for '{movie_title}'.")
        return pd.DataFrame()

    movie_details = [get_movie_details(row['id']) for _, row in df.iterrows()]
    movies_df = pd.DataFrame(movie_details)

    # Normalize numeric features
    scaler = MinMaxScaler()
    movies_df[['vote_average', 'vote_count']] = scaler.fit_transform(movies_df[['vote_average', 'vote_count']])
    
    # Process textual data (overview, title, directors, actors, genres)
    tfidf = TfidfVectorizer(stop_words='english')
    movies_df['overview'] = movies_df['overview'].fillna('')
    movies_df['title'] = movies_df['title'].astype(str)
    
    movies_df['directors'] = movies_df['directors'].apply(lambda x: ' '.join(x) if isinstance(x, list) else x)
    movies_df['actors'] = movies_df['actors'].apply(lambda x: ' '.join(x) if isinstance(x, list) else x)
    movies_df['genres'] = movies_df['genres'].apply(lambda x: ' '.join(x) if isinstance(x, list) else x)
    
    # Concatenate the textual features
    textual_features = movies_df['overview']+ " " + movies_df['title'] + " " + movies_df['directors'] + " " + movies_df['actors'] + " " + movies_df['genres'] + " " + movies_df['overview']
    tfidf_matrix = tfidf.fit_transform(textual_features)
    
    # Combine features
    combined_features = np.hstack((tfidf_matrix.toarray(), movies_df[['vote_average', 'vote_count']].to_numpy()))
    
    # Compute similarity
    cosine_sim = linear_kernel(combined_features, combined_features)

    sim_scores = list(enumerate(cosine_sim[0]))
    
    # Here we ensure we don't try to recommend more movies than available by adjusting num_recommendations
    num_recommendations = min(num_recommendations, len(sim_scores) - 1)
    
    random_indices = random.sample(range(len(movies_df)), num_recommendations)
    recommended_movies = movies_df.iloc[random_indices]

    return recommended_movies
    

# from sklearn.feature_extraction.text import TfidfVectorizer
# from sklearn.preprocessing import MinMaxScaler
# from sklearn.neighbors import NearestNeighbors
# import pandas as pd
# import numpy as np

# def get_recommendations(movie_title, num_recommendations=5):
#     df = search_movies(movie_title)  # Ensure this function returns a DataFrame with movie details
#     if df.empty:
#         print(f"No movies found for '{movie_title}'.")
#         return pd.DataFrame()

#     movie_details = [get_movie_details(row['id']) for _, row in df.iterrows()]
#     movies_df = pd.DataFrame(movie_details)
    
#     # Adjust num_recommendations based on the number of movies found
#     num_recommendations = min(num_recommendations, len(movies_df) - 1)
#     if num_recommendations < 1:
#         print("Not enough movies for recommendations.")
#         return pd.DataFrame()
#     # Normalize numeric features
#     scaler = MinMaxScaler()
#     movies_df[['vote_average', 'vote_count']] = scaler.fit_transform(movies_df[['vote_average', 'vote_count']])
    
#     # Process textual data (overview, title, directors, actors, genres)
#     tfidf = TfidfVectorizer(stop_words='english')
#     movies_df['overview'] = movies_df['overview'].fillna('')
#     movies_df['title'] = movies_df['title'].astype(str)
    
#     movies_df['directors'] = movies_df['directors'].apply(lambda x: ' '.join(x) if isinstance(x, list) else x)
#     movies_df['actors'] = movies_df['actors'].apply(lambda x: ' '.join(x) if isinstance(x, list) else x)
#     movies_df['genres'] = movies_df['genres'].apply(lambda x: ' '.join(x) if isinstance(x, list) else x)
    
#     # Concatenate the textual features
#     textual_features = movies_df['title'] + " " + movies_df['directors'] + " " + movies_df['actors'] + " " + movies_df['genres'] + " " + movies_df['overview']
#     tfidf_matrix = tfidf.fit_transform(textual_features)
    
#     # Combine features
#     combined_features = np.hstack((tfidf_matrix.toarray(), movies_df[['vote_average', 'vote_count']].to_numpy()))
    
#     # Initialize and fit KNN model
#     knn = NearestNeighbors(n_neighbors=num_recommendations + 1, metric='cosine')
#     knn.fit(combined_features)
    
#     # Assuming the first movie is the target, find its K nearest neighbors
#     distances, indices = knn.kneighbors(combined_features[0:1], n_neighbors=num_recommendations + 1)
    
#     # Skipping the first index since it's the movie itself
#     movie_indices = indices[0][1:]
    
#     return movies_df.iloc[movie_indices].reset_index(drop=True)
