from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base  
import models
SQLALCHEMY_DATABASE_URL = "postgresql://postgres:A2310@localhost/netfloox"

engine = create_engine(
      SQLALCHEMY_DATABASE_URL
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def create_tables():
    Base.metadata.create_all(bind=engine)
if __name__ == "__main__":
    create_tables()