import bcrypt
from sqlalchemy.orm import Session
import models
from schemas import UserCreate

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def create_user(db: Session, user: UserCreate):
    hashed_password = bcrypt.hashpw(user.password.encode('utf-8'), bcrypt.gensalt())
    db_user = models.User(username=user.username, email=user.email, hashed_password=hashed_password.decode('utf-8'))
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def authenticate_user(db: Session, username: str, password: str):
    # Assuming username is unique and used for login
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user:
        return False
    # Now, user.hashed_password refers to the hashed_password of the retrieved user instance
    if bcrypt.checkpw(password.encode('utf-8'), user.hashed_password.encode('utf-8')):
        return user
    else:
        return False


# def get_user_by_email(db: Session, email: str):
#     return db.query(models.User).filter(models.User.email == email).first()

# def authenticate_user(db: Session, email: str, password: str):
#     user = get_user_by_email(db, email)
#     if not user:
#         return False
#     if bcrypt.checkpw(password.encode('utf-8'), user.hashed_password.encode('utf-8')):
#         return user
#     return False
    
    from sqlalchemy.orm import Session

# def get_user(db: Session, user_id: int):
#     return db.query(models.User).filter(models.User.id == user_id).first()

# def get_movie(db: Session, movie_id: int):
#     return db.query(models.Movie).filter(models.Movie.id == movie_id).first()

# def is_movie_liked_by_user(db: Session, user_id: int, movie_id: int):
#     return db.query(models.Like).filter(models.Like.user_id == user_id, models.Like.movie_id == movie_id).first() is not None

# def get_user_movie_titles(db: Session, user_id: int) -> list:
#     return db.query(models.Like.movie_title).filter(models.Like.user_id == user_id).all()

def get_user_movie_titles(db: Session, user_id: int) -> list:
    result = db.query(models.Like.movie_title).filter(models.Like.user_id == user_id).all()
    return [title[0] for title in result] 