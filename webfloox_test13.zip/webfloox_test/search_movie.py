from fastapi import APIRouter
router = APIRouter()
from fastapi import FastAPI, Form, HTTPException, Request , Query
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import requests
import os
from typing import List, Optional
from fastapi.staticfiles import StaticFiles
import pandas as pd 
import json


templates = Jinja2Templates(directory="templates")
TMDB_API_KEY = 'b7cd3340a794e5a2f35e3abb820b497f'
TMDB_BASE_URL = "https://api.themoviedb.org/3"

app = FastAPI()

app.mount("/static", StaticFiles(directory="static"), name="static")



def get_movie_id_by_title(movie_title: str) -> int:
    search_url = f"{TMDB_BASE_URL}/search/movie"
    params = {
        'api_key': TMDB_API_KEY,
        'query': movie_title
    }
    
    response = requests.get(search_url, params=params)
    response_json = response.json()
    
 
    results = response_json.get('results')
    if results:
        # Return the ID of the first movie in the results
        return results[0]
    else:
        return None
    


def get_movie_title_by_id(movie_id: int) -> int:
    movie_url = f"{TMDB_BASE_URL}/movie/{movie_id}"
    params = {
        'api_key': TMDB_API_KEY
    }
    
    response = requests.get(movie_url, params=params)
    if response.status_code == 200:
        movie_details = response.json()
        # Return the title of the movie
        return movie_details.get('title')
    else:
        return None



def get_recommendations1(movie_id: int) -> List[dict]:
    recommendations_url = f"{TMDB_BASE_URL}/movie/{movie_id}/recommendations"
    response = requests.get(recommendations_url, params={"api_key": TMDB_API_KEY})
    results = response.json().get("results", [])
    return results

def get_similar_movies(movie_id: int) -> List[dict]:
    """Fetch similar movies based on a movie ID from TMDB."""
    similar_movies_url = f"{TMDB_BASE_URL}/movie/{movie_id}/similar"
    response = requests.get(similar_movies_url, params={"api_key": TMDB_API_KEY})
    results = response.json().get("results", [])
    return results

# @router.get("/search_movie", response_class=HTMLResponse)
# async def search_movie(request: Request, title: str, recommendations: bool = False, similar: bool = False):
#     movie_details = get_movie_id_by_title(title)
#     if not movie_details:
#         raise HTTPException(status_code=404, detail="Movie not found")

#     # Initialize an empty dict to hold any additional data
#     recommendations = get_recommendations(movie_details["id"])
#     similar_movies = get_similar_movies(movie_details["id"])
    
#     return templates.TemplateResponse("movie_details.html", {
#         "request": request,
#         "movie": movie_details,
#         "recommendations": recommendations,
#         "similar_movies": similar_movies
#     })


# Run the app with: uvicorn main:app --reload
