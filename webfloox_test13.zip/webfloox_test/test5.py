@app.post("/toggle-like")
async def toggle_like(request: Request, movie_title: str = Form(), db: Session = Depends(get_db)):
    # Assume we somehow get the current_user_id (this should be replaced with actual user authentication logic)
    current_user_id = 1

    liked_movie = db.query(Like).filter(Like.user_id == current_user_id, Like.movie_title == movie_title).first()

    if liked_movie:
        # If already liked, remove the like
        db.delete(liked_movie)
    else:
        # If not liked, add a new like
        new_like = Like(user_id=current_user_id, movie_title=movie_title)
        db.add(new_like)
        
    
    db.commit()

    return 


